import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { Activity, Shield, AlertTriangle, Settings, FileText, Server } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import Simulation from './pages/Simulation';
import Monitoring from './pages/Monitoring';

function App() {
  return (
    <BrowserRouter>
      <div className="flex h-screen bg-slate-950 text-slate-100 font-sans">
        {/* Sidebar */}
        <div className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col">
          <div className="p-6 flex items-center space-x-3">
            <Shield className="w-8 h-8 text-cyan-500" />
            <h1 className="text-xl font-bold tracking-wider text-slate-100">CyberTwin-X</h1>
          </div>
          <nav className="flex-1 px-4 space-y-2 mt-4">
            <Link to="/dashboard" className="flex items-center space-x-3 px-3 py-2 rounded-md hover:bg-slate-800 text-slate-300 hover:text-white transition-colors">
              <Activity className="w-5 h-5" /> <span>Dashboard</span>
            </Link>
            <Link to="/simulation" className="flex items-center space-x-3 px-3 py-2 rounded-md hover:bg-slate-800 text-slate-300 hover:text-white transition-colors">
              <Server className="w-5 h-5" /> <span>Simulation</span>
            </Link>
            <Link to="/monitoring" className="flex items-center space-x-3 px-3 py-2 rounded-md hover:bg-slate-800 text-slate-300 hover:text-white transition-colors">
              <Activity className="w-5 h-5" /> <span>Monitoring</span>
            </Link>
          </nav>
        </div>
        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-950 p-6">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/simulation" element={<Simulation />} />
              <Route path="/monitoring" element={<Monitoring />} />
            </Routes>
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;\n